#ifndef PIXEL_H
#define PIXEL_H

struct _pixel{
	float r;
	float g;
	float b;
	int x;
	int y;
};
typedef struct _pixel Pixel;

